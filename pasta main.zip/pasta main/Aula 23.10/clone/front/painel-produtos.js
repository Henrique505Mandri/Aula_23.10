export default {
    template: `
        <div class="p-2 bg-gray-50">
            <p>Produtos</p>
            <button class="border rounded px-1 hover:bg-gray-100 text-sm" id="btn1">GET</button>
            <button class="border rounded px-1 hover:bg-gray-100 text-sm" id="btn2">POST</button>
            <button class="border rounded px-1 hover:bg-gray-100 text-sm" id="btn3">PUT</button>
            <button class="border rounded px-1 hover:bg-gray-100 text-sm" id="btn4">DELETE</button>
        </div>    
    `,
    data() {
        return {
        }
    },
    methods: {
    }
}