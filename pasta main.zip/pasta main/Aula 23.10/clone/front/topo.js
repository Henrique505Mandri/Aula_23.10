
export default {
    template: `
        <div class="flex items-center text-lg border p-2 bg-indigo-50">
            <span class="iconify mr-1" data-icon="carbon:server-dns"></span>
            Meu teste do servidor 
        </div>
    `,
    data() {
        return {
        }
    },
    methods: {
    }
}