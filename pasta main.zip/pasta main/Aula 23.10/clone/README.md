# Aula08 / Aula09 SDM 19-04 / 26/04 Noite

## Versão API com persistência de dados e com front-end de teste

1. Para brincar esse projeto:
    - copiar o endereço: https://github.com/mmamorim/Aula08SDM1904Noite.git
    - Em alguma pasta do seu computador, abrir terminal (git bash here)     
    - clonar o repositório nesta pasta local por meio do comando: 
     
    `git clone https://github.com/mmamorim/Aula08SDM1904Noite.git`

2. Abrir a pasta com o VSCode

3. Abrir um terminal no VSCode

4. Vamos gerar os modulos de dependencia indicado no "package.json"

    `npm install`

5. Para executar:

    `npm run server`

6. Se quiser testar as rotas, instale no VSCode a extensão:

    `thunder client`
