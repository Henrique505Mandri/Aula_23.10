<template>
  <div>
    oi gente 
    <teste />
  </div>
</template>

<script>
import teste from "./components/teste.vue"

export default {
  components: { teste }
}
</script>

<style>

</style>